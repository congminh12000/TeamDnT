<style id="cornerstone-global-style"><?php echo $this->global_style; ?></style>
